import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Ga nu naar Bamboe!
        </p>
        <a
          className="App-link"
          href="http://Bamboe.ml"
          target="_blank"
          rel="noopener noreferrer"
        >
          Bamboe
        </a>
      </header>
    </div>
  );
}

export default App;
